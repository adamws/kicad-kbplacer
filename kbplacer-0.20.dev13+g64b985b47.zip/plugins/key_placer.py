# SPDX-FileCopyrightText: 2025 adamws <adamws@users.noreply.github.com>
#
# SPDX-License-Identifier: GPL-3.0-or-later

from __future__ import annotations

import copy
import itertools
import logging
import os
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import (
    Any,
    Dict,
    FrozenSet,
    Hashable,
    Iterable,
    Iterator,
    List,
    Optional,
    Set,
    Tuple,
    Union,
    cast,
)

import pcbnew

from .board_modifier import (
    KICAD_VERSION,
    BoardModifier,
    calculate_distance_matrix,
    duplicate_footprint,
    duplicate_track,
    get_closest_pads_on_same_net,
    get_common_nets,
    get_distance,
    get_footprint,
    get_optional_footprint,
    get_orientation,
    get_pads_by_net,
    get_position,
    get_side,
    position_in_rotated_coordinates,
    prim_mst,
    reset_rotation,
    rotate,
    set_position,
    set_rotation,
    set_side,
)
from .connection_preset import (
    ConnectionPreset,
    is_json_preset,
    normalize_template_tracks,
    preset_diode_positions,
    preset_items_to_tracks,
)
from .element_position import ElementInfo, ElementPosition, PositionOption
from .kle_serial import (
    Key,
    Keyboard,
    KeyboardTag,
    MatrixAnnotatedKeyboard,
    get_keyboard_from_path_or_url,
    is_iso_enter,
    layout_classification,
)
from .plugin_error import PluginError
from .preset_format import load_switch_preset

logger = logging.getLogger(__name__)
ANNOTATION_GUIDE_URL = (
    "https://github.com/adamws/kicad-kbplacer/blob/master/docs/annotation_guide.md"
)


class KeyMatrix:
    SUPPORTED_ROW_NAMES = ["ROW{}", "R{}", "/ROW{}", "/R{}"]
    SUPPORTED_COLUMN_NAMES = ["COLUMN{}", "COL{}", "C{}", "/COLUMN{}", "/COL{}", "/C{}"]

    def __init__(self, board: pcbnew.BOARD, key_format: str, diode_format: str) -> None:
        self.key_format = key_format
        self.diode_format = diode_format

        self._row_format = ""
        self._column_format = ""

        self._switches: Dict[str, pcbnew.FOOTPRINT] = {}
        self._switches_references_by_net: Dict[FrozenSet[str], List[str]] = defaultdict(
            list
        )
        self._diodes_by_switch: Dict[str, List[pcbnew.FOOTPRINT]] = defaultdict(list)

        diodes: List[pcbnew.FOOTPRINT] = []

        switches_nets: Dict[str, Set[str]] = defaultdict(set)
        all_switches_nets: Set[str] = set()
        diodes_nets_by_reference: Dict[str, Set[str]] = defaultdict(set)
        diodes_unique_nets: Dict[str, Set[str]] = {}

        self.key_pattern = re.compile(key_format.format("(.*)"))
        self.diode_pattern = re.compile(diode_format.format("(.*)"))

        def _get_nets(f: pcbnew.FOOTPRINT) -> List[str]:
            return [p.GetNetname() for p in f.Pads() if p.GetNetname() != ""]

        for f in board.GetFootprints():
            reference = f.GetReference()
            if re.match(self.key_pattern, reference):
                self._switches[reference] = f
                nets = _get_nets(f)
                switches_nets[reference].update(nets)
                all_switches_nets.update(nets)
            elif re.match(self.diode_pattern, reference):
                diodes.append(f)
                diodes_nets_by_reference[reference].update(_get_nets(f))

        # reduce diode_nets to contain only diode-unique nets
        # (i.e. not common with any switch)
        for k, v in diodes_nets_by_reference.items():
            diodes_unique_nets[k] = v.difference(all_switches_nets)

        # each switch can have 0 or more diodes
        for f in diodes:
            reference = f.GetReference()
            for switch_reference, key in self._switches.items():
                diodes_nets = diodes_nets_by_reference[reference]
                switch_nets = [p.GetNetname() for p in key.Pads()]
                if common_nets := list(diodes_nets.intersection(switch_nets)):
                    self._diodes_by_switch[switch_reference].append(f)
                    # remove common switch-diode net and add diode-unique net instead,
                    # this way we should get key-matrix nets:
                    for net in common_nets:
                        switches_nets[switch_reference].discard(net)
                    switches_nets[switch_reference].update(
                        diodes_unique_nets[reference]
                    )

        self._invalid_switches: Dict[str, Set[str]] = {}
        for k, v in switches_nets.items():
            if len(v) == 2:
                self._switches_references_by_net[frozenset(v)].append(k)
            else:
                self._invalid_switches[k] = set(v)
        if self._invalid_switches:
            details = ", ".join(
                f"{ref} (nets: {sorted(nets) if nets else 'none'})"
                for ref, nets in sorted(self._invalid_switches.items())
            )
            logger.warning(
                "Unexpected switch net position detected. Each switch should have "
                "exactly two unique nets unambiguously defining its position in the "
                "key matrix (one ROW and one COL). The following switches do not: "
                f"{details}. Their pads may be unconnected or wired incorrectly, so "
                "switch-by-matrix association can't be used."
            )
            self._switches_references_by_net = {}
        logger.debug(f"Switches by nets: {self._switches_references_by_net}")
        self._diodes_references_by_switch = {
            k: [f.GetReference() for f in v] for k, v in self._diodes_by_switch.items()
        }
        logger.debug(f"Diodes by switch: {self._diodes_references_by_switch}")

    def first_switch_reference(self) -> str:
        return min(self._switches)

    def number_of_switches(self) -> int:
        return len(self._switches)

    def switch_by_reference(self, reference: str) -> pcbnew.FOOTPRINT:
        return self._switches[reference]

    def switch_by_format_value(self, value: Any) -> pcbnew.FOOTPRINT:
        return self._switches[self.key_format.format(value)]

    def switches_by_reference(self) -> Iterable[Tuple[str, pcbnew.FOOTPRINT]]:
        return self._switches.items()

    def switches_by_reference_ordered(self) -> Iterable[Tuple[str, pcbnew.FOOTPRINT]]:
        def _tryint(s: str) -> Union[str, int]:
            try:
                return int(s)
            except ValueError:
                return s

        def _alphanum_keys(item: Tuple[str, pcbnew.FOOTPRINT]) -> List[Union[str, int]]:
            return [_tryint(c) for c in re.split("([0-9]+)", item[0])]

        return sorted(self._switches.items(), key=_alphanum_keys)

    def is_matrix_ok(self) -> bool:
        return len(self._switches_references_by_net) != 0

    def invalid_switches(self) -> Dict[str, Set[str]]:
        """Switches which do not have exactly two matrix nets, keyed by
        reference with their detected nets. Populated when matrix association
        fails so callers can report the offending footprints."""
        return self._invalid_switches

    def is_likely_direct_pin(self) -> bool:
        # assume that matrix netlist is direct-pin if:
        # 1) none of the switch has diode connected to it
        # 2) all of the switches are connected to GND on the one side
        no_diodes = all(
            len(lst) == 0 for lst in self._diodes_references_by_switch.values()
        )
        all_use_gnd = all(
            any(net in key for net in ["GND", "Gnd", "gnd"])
            for key in self._switches_references_by_net.keys()
        )
        return no_diodes and all_use_gnd

    def __guess_format(self, guesses: List[str]) -> str:
        for guess in guesses:
            pattern = re.compile(guess.format("(\\d)+"))
            for net in self.matrix_nets():
                if re.match(pattern, net):
                    return guess
        # out of luck, getting switches by row,column annotation won't work
        return ""

    @property
    def row_format(self) -> str:
        if not self._row_format:
            self._row_format = self.__guess_format(KeyMatrix.SUPPORTED_ROW_NAMES)
        return self._row_format

    @property
    def column_format(self) -> str:
        if not self._column_format:
            self._column_format = self.__guess_format(KeyMatrix.SUPPORTED_COLUMN_NAMES)
        return self._column_format

    def switches_references_by_coordinates(self, row: int, column: int) -> List[str]:
        return self.switches_references_by_netnames(
            self.row_format.format(row), self.column_format.format(column)
        )

    def switches_references_by_netnames(
        self, row_net: str, column_net: str
    ) -> List[str]:
        nets = (row_net, column_net)
        return self._switches_references_by_net[frozenset(nets)]

    def switches_references_by_netname(self, netname: str) -> List[str]:
        result = []
        for nets, switches in self._switches_references_by_net.items():
            if netname in nets:
                result.extend(switches)
        return result

    def diodes_by_switch_reference(self, reference: str) -> List[pcbnew.FOOTPRINT]:
        return self._diodes_by_switch[reference]

    def any_switch_with_multiple_diodes(self) -> bool:
        return any(len(d) > 1 for d in self._diodes_by_switch.values())

    def matrix_nets(self) -> Set[str]:
        return set().union(*self._switches_references_by_net)

    def matrix_rows(self) -> Set[str]:
        pattern = re.compile(self.row_format.format("(\\d)+"))
        return {net for net in self.matrix_nets() if re.match(pattern, net)}

    def matrix_columns(self) -> Set[str]:
        pattern = re.compile(self.column_format.format("(\\d)+"))
        return {net for net in self.matrix_nets() if re.match(pattern, net)}


class KeyboardSwitchIterator:
    EXPLICIT_ANNOTATION_LABEL = 10

    def __init__(
        self,
        keyboard: Keyboard,
        key_matrix: KeyMatrix,
        start_index: int = 1,
    ) -> None:
        self._keyboard = keyboard
        self._key_matrix = key_matrix
        self.explicit_annotations = self.__check_explicit_annotations(keyboard)
        self._keys = iter(self._keyboard.keys)
        self._current_key = start_index

    def __check_explicit_annotations(self, keyboard: Keyboard) -> bool:
        number_of_explicit_annotations = sum(
            str(k.get_label(self.EXPLICIT_ANNOTATION_LABEL)).isdigit()
            for k in keyboard.keys
        )
        return number_of_explicit_annotations == len(keyboard.keys)

    def __iter__(self):
        return self

    def __get_footprint(self, key: Key) -> pcbnew.FOOTPRINT:
        if self.explicit_annotations:
            label = key.labels[self.EXPLICIT_ANNOTATION_LABEL]
            try:
                sw = self._key_matrix.switch_by_format_value(label)
            except KeyError as e:
                msg = (
                    "Provided keyboard layout uses explicit annotations "
                    f"but could not find switch {e}, aborting."
                )
                raise PluginError(msg)
        else:
            try:
                sw = self._key_matrix.switch_by_format_value(self._current_key)
            except KeyError as e:
                msg = (
                    f"Could not find switch {e}, aborting.\n"
                    f"Provided keyboard layout requires {len(self._keyboard.keys)} "
                    f"keys, found {self._key_matrix.number_of_switches()} "
                    f"footprints with '{self._key_matrix.key_format}' annotation."
                )
                raise PluginError(msg)
            self._current_key += 1
        return sw

    def __next__(self):
        key = next(self._keys)
        if key:
            if key.decal:
                return self.__next__()
            return key, self.__get_footprint(key)
        else:
            raise StopIteration


class MatrixAnnotatedKeyboardSwitchIterator:
    def __init__(
        self,
        keyboard: MatrixAnnotatedKeyboard,
        key_matrix: KeyMatrix,
    ) -> None:
        self._keyboard = keyboard
        self._key_matrix = key_matrix
        self._keys = self._keyboard.key_iterator(ignore_alternative=False)
        self._seen: Counter[Tuple[str, str]] = Counter()

    def __iter__(self):
        return self

    def __get_footprint(self, key: Key) -> Optional[pcbnew.FOOTPRINT]:
        matrix_coordinates = MatrixAnnotatedKeyboard.get_matrix_position(key)
        layout_option = self._seen[matrix_coordinates]

        if all(c.isdigit() for c in matrix_coordinates):
            switches = self._key_matrix.switches_references_by_coordinates(
                *map(int, matrix_coordinates)
            )
            net_names_inferred = True
        else:
            # supporting via-like annotation where net names are explicitly
            # stated in layout file
            switches = self._key_matrix.switches_references_by_netnames(
                *matrix_coordinates
            )
            net_names_inferred = False
        switches = sorted(switches)
        logger.debug(f"Got {switches} for {matrix_coordinates} position")
        if len(switches) == 0:
            msg = (
                f"Could not find switches connected to {matrix_coordinates} matrix position "
                "which is used in provided layout.\n"
                "Either required footprint is missing or it can't be found due to unexpected "
                "net names.\n"
            )
            if net_names_inferred:
                names = KeyMatrix.SUPPORTED_ROW_NAMES + KeyMatrix.SUPPORTED_COLUMN_NAMES
                msg += (
                    "When using via-annotated layouts it must be possible to associate "
                    "footprints with following net names:\n" + ", ".join(names)
                )
            raise PluginError(msg)

        # assume that alternative keys have same annotation with
        # some sort of suffix so after sorting
        # the option index would get us correct footprint
        try:
            # due to layout collapsing the choices might be missing,
            # instead of using choice value use number of already seen switches
            switch = switches[layout_option]
            fp = self._key_matrix.switch_by_reference(switch)
            self._seen[matrix_coordinates] += 1
            return fp
        except Exception:
            logger.warning(
                "Could not find {} layout footprint".format(
                    "default" if layout_option == 0 else "alternative"
                )
            )
            return None

    def __next__(self):
        key = next(self._keys)
        if key:
            if key.decal:
                return self.__next__()
            if not (footprint := self.__get_footprint(key)):
                return self.__next__()
            return key, footprint
        else:
            raise StopIteration


def get_key_iterator(
    keyboard: Keyboard,
    key_matrix: KeyMatrix,
    start_index: int = 1,
) -> Iterator:
    if isinstance(keyboard, MatrixAnnotatedKeyboard):
        if not key_matrix.is_matrix_ok():
            invalid = key_matrix.invalid_switches()
            if invalid:
                details = ", ".join(
                    f"{ref} (nets: {sorted(nets) if nets else 'none'})"
                    for ref, nets in sorted(invalid.items())
                )
                reason = (
                    "The following switch footprints do not have exactly two "
                    f"matrix nets (one ROW, one COL): {details}.\n"
                    "Their pads appear unconnected or incorrectly wired.\n"
                )
            else:
                reason = "Either net names are unrecognized or netlist is invalid.\n"
            msg = (
                "Detected layout file with via-annotated matrix positions "
                "while not all footprints on PCB can be unambiguously associated "
                "with row/column position.\n"
                f"{reason}"
                "Fix netlist problems or use layout file which uses 'explicit annotation'.\n"
                f"For details see {ANNOTATION_GUIDE_URL}"
            )
            raise PluginError(msg)
        if key_matrix.is_likely_direct_pin():
            msg = (
                "Detected layout file with via-annotated matrix positions "
                "while key connections appear to be direct-pin (no matrix with diodes found).\n"
                "This means that footprints on PCB can't be reliably matched to layout.\n"
                "Please use layout file which uses 'explicit annotation'.\n"
                f"For details see {ANNOTATION_GUIDE_URL}"
            )
            raise PluginError(msg)
        _iter = MatrixAnnotatedKeyboardSwitchIterator(keyboard, key_matrix)
    else:
        _iter = KeyboardSwitchIterator(keyboard, key_matrix, start_index)
    return iter(_iter)


PadGroup = List[Tuple[str, pcbnew.PAD]]


def _group_connected_pads(
    switch: pcbnew.FOOTPRINT,
    diodes: List[pcbnew.FOOTPRINT],
    tracks: List[pcbnew.PCB_TRACK],
) -> List[PadGroup]:
    """Groups pads of `switch` and `diodes` connected with each other by `tracks`.
    Tracks are connected when their endpoints match exactly (as template
    replication produces them), vias connect both copper layers.

    :return: Groups of at least two (footprint reference, pad) pairs.
    """
    parent: Dict[Hashable, Hashable] = {}

    def _find(x: Hashable) -> Hashable:
        parent.setdefault(x, x)
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def _union(a: Hashable, b: Hashable) -> None:
        parent[_find(a)] = _find(b)

    # track endpoints keyed by (x, y, layer)
    anchors: Dict[Tuple[int, int, int], pcbnew.VECTOR2I] = {}
    for t in tracks:
        if t.Type() == pcbnew.PCB_VIA_T:
            position = t.GetPosition()
            keys = [
                (position.x, position.y, layer) for layer in (pcbnew.F_Cu, pcbnew.B_Cu)
            ]
            for key in keys:
                anchors[key] = position
        else:
            start, end = t.GetStart(), t.GetEnd()
            keys = [(start.x, start.y, t.GetLayer()), (end.x, end.y, t.GetLayer())]
            anchors[keys[0]] = start
            anchors[keys[1]] = end
        _union(keys[0], keys[1])

    pads = [(f.GetReference(), p) for f in [switch, *diodes] for p in f.Pads()]
    for i, (_, pad) in enumerate(pads):
        _find(i)
        for key, point in anchors.items():
            if pad.IsOnLayer(key[2]) and pad.HitTest(point):
                _union(i, key)

    groups: Dict[Hashable, PadGroup] = defaultdict(list)
    for i, item in enumerate(pads):
        groups[_find(i)].append(item)
    return [g for g in groups.values() if len(g) > 1]


def _group_connects(
    group: PadGroup, switch_reference: str, diode_reference: str, nets: Set[int]
) -> bool:
    switch_nets = {p.GetNetCode() for r, p in group if r == switch_reference}
    diode_nets = {p.GetNetCode() for r, p in group if r == diode_reference}
    return bool(nets & switch_nets & diode_nets)


class KeyPlacer(BoardModifier):
    def __init__(
        self,
        board: pcbnew.BOARD,
    ) -> None:
        super().__init__(board)
        self._stab_rotation_by_switch: dict = {}
        self._connection_presets: Dict[str, ConnectionPreset] = {}

    def apply_switch_connection_template(
        self,
        switch: pcbnew.FOOTPRINT,
        angle: float,
        template_connection: List[pcbnew.PCB_TRACK],
    ) -> List[pcbnew.PCB_TRACK]:
        """
        :param switch: Switch footprint to be routed.
        :param angle: Rotation angle (in degrees) of switch footprint
                      (diode rotation is assumed to be the same)
        :param template_connection: List of template elements (tracks and vias) for
                                    routing switch and diode pads. Normalised to
                                    switch position coordinate. Templates
                                    items must not have netcodes assigned.
        :return: Elements added to the board.
        """
        logger.info("Using template replication method")
        if angle != 0:
            logger.info(f"Routing at {angle} degree angle")
        switch_position = get_position(switch)
        placed = []
        rejects = []
        for item in template_connection:
            # item is either PCB_TRACK or PCB_VIA, since via extends track
            # we should be safe with `Cast_to_PCB_TRACK` (not doing any via
            # specific operations here)
            track = pcbnew.Cast_to_PCB_TRACK(item)
            new_track = duplicate_track(track)
            if KICAD_VERSION < (7, 0, 0):
                new_track.Move(pcbnew.wxPoint(switch_position.x, switch_position.y))
            else:
                new_track.Move(switch_position)
            if angle != 0:
                rotate(new_track, switch_position, angle)
            result = self.add_track_to_board(new_track)
            # depending on the order of track elements placement, some may not pass
            # collision check (for example when starting from middle segment,
            # if it ends to close to a pad). To avoid rejecting false positives,
            # collect rejects and give them a second chance. Only the 'middle' segments
            # (i.e. not starting in a pad) should be in this list, others should
            # get placed properly (unless indeed colliding with some footprints,
            # for example optional stabilizer holes), so running placement of rejects
            # a second time should succeed.
            if result is None:
                rejects.append(new_track)
            else:
                placed.append(new_track)
        for item in rejects:
            if self.add_track_to_board(item) is not None:
                placed.append(item)
        return placed

    def route_switch_with_diode(
        self,
        switch: pcbnew.FOOTPRINT,
        diodes: List[pcbnew.FOOTPRINT],
    ) -> None:
        """Performs routing between switch and diode elements.
        It uses two closest (to each other) pads of the same net.

        :param switch: Switch footprint to be routed.
        :param diodes: Diodes footprints to be routed.
        """
        for diode in diodes:
            logger.info(f"Routing {switch.GetReference()} with {diode.GetReference()}")
            if result := get_closest_pads_on_same_net(switch, diode):
                logger.info("Using internal autorouter method")
                switch_pad, diode_pad = result
                self.route(switch_pad, diode_pad)
            else:
                logger.error("Could not find pads with the same net, routing skipped")

    def get_current_relative_element_position(
        self, element1: pcbnew.FOOTPRINT, element2: pcbnew.FOOTPRINT
    ) -> ElementPosition:
        """Returns position of element2 in relation to element1
        in element1 coordinate system (i.e centered in element1 center
        and rotated by its rotation)
        """
        pos1 = get_position(element1)
        pos2 = get_position(element2)
        rot1 = get_orientation(element1)
        rot2 = get_orientation(element2)
        if rot1:
            pos1 = position_in_rotated_coordinates(pos1, -rot1)
            pos2 = position_in_rotated_coordinates(pos2, -rot1)

        x = cast(float, pcbnew.ToMM(pos2.x - pos1.x))
        y = cast(float, pcbnew.ToMM(pos2.y - pos1.y))

        return ElementPosition(
            x,
            y,
            rot2 - rot1,
            get_side(element2),
        )

    def remove_dangling_tracks(self) -> None:
        logger.info("Removing dangling tracks")

        def _is_dangling(
            connectivity: pcbnew.CONNECTIVITY_DATA, track: pcbnew.PCB_TRACK
        ) -> bool:
            if KICAD_VERSION >= (7, 0, 7):
                return connectivity.TestTrackEndpointDangling(track, False)
            return connectivity.TestTrackEndpointDangling(track)

        any_removed = True
        while any_removed:
            any_removed = False
            connectivity = self.get_connectivity()
            for track in self.board.GetTracks():
                if _is_dangling(connectivity, track):
                    logger.info(f"Removing {track.m_Uuid.AsString()}")
                    self.board.RemoveNative(track)
                    any_removed = True

    def save_connection_template(
        self,
        switch: pcbnew.FOOTPRINT,
        diodes: List[pcbnew.FOOTPRINT],
        connections: List[pcbnew.PCB_TRACK],
        destination_path: str,
    ) -> None:
        logger.info(f"Saving template to {destination_path}")
        # can't use `CreateEmptyBoard` when running inside KiCad.
        # We want new board file but without new project file,
        # looks like this is not possible with pcbnew API.
        # So create board with project
        board = pcbnew.NewBoard(destination_path)
        # and delete project file
        os.remove(Path(destination_path).with_suffix(".kicad_pro"))

        switch_copy = duplicate_footprint(switch)
        reset_rotation(switch_copy)
        set_position(switch_copy, pcbnew.VECTOR2I(0, 0))

        origin = get_position(switch)
        diode_copies = []
        for d in diodes:
            diode_copy = duplicate_footprint(d)
            if angle := get_orientation(switch):
                rotate(diode_copy, origin, angle)
            set_position(
                diode_copy,
                get_position(diode_copy) - origin,
            )
            diode_copies.append(diode_copy)

        for p in itertools.chain(
            switch_copy.Pads(),
            itertools.chain.from_iterable((d.Pads() for d in diode_copies)),
        ):
            if p.GetNetCode() != 0:
                logger.info(
                    f"Adding net {p.GetNetname()} with netcode {p.GetNetCode()}"
                )
                # adding nets to new board will get them new autoassigned netcodes
                # (the one set at `NETINFO_ITEM` constructor will be discarded)
                net = pcbnew.NETINFO_ITEM(board, p.GetNetname(), -1)
                board.Add(net)

        nets = board.GetNetsByName()
        # synchronize net codes
        for p in itertools.chain(
            switch_copy.Pads(),
            itertools.chain.from_iterable((d.Pads() for d in diode_copies)),
        ):
            if p.GetNetCode() != 0:
                before = p.GetNetCode()
                p.SetNet(nets[p.GetNetname()])
                logger.info(
                    f"Updating pad '{p.GetParentAsString()}:{p.GetPadName()}' "
                    f"net {p.GetNetname()} netcode: {before} -> {p.GetNetCode()}"
                )

        board.Add(switch_copy)
        for d in diode_copies:
            board.Add(d)

        for item in connections:
            # using `Duplicate` here to not alter net assignments of original tracks
            # (which needs to be empty in order to work as template)
            board.Add(duplicate_track(item))
        pcbnew.SaveBoard(destination_path, board, aSkipSettings=True)

    def get_connection_template(
        self,
        key_info: ElementInfo,
        diode_format: str,
        destination_path: str,
        route: bool,
    ) -> List[pcbnew.PCB_TRACK]:
        """Returns list of tracks (including vias) connecting first element
        with reference `key_info.annotation_format` to itself or any other element
        and optionally save it to new `pcbnew` template file.
        The coordinates of returned elements are normalized to center of `key_info.annotation_format`
        element. If `key_info.annotation_format` element is rotated, resulting coordinates are rotated
        back so the template is always in natural (0) orientation.
        """
        key_format = key_info.annotation_format
        start_index = key_info.start_index

        switch = get_footprint(self.board, key_format.format(start_index))

        logger.info(
            "Looking for connection template between "
            f"{switch.GetReference()} and other elements"
        )
        result = []
        origin = get_position(switch)

        connectivity = self.get_connectivity()
        _tracks: Dict[str, pcbnew.PCB_TRACE_T] = {}

        def _get_connected_tracks(item: pcbnew.BOARD_CONNECTED_ITEM) -> None:
            for t in connectivity.GetConnectedTracks(item):
                uid = t.m_Uuid.AsString()
                if uid not in _tracks:
                    _tracks[uid] = t
                    _get_connected_tracks(t)

        for p in switch.Pads():
            _get_connected_tracks(p)

        for item in _tracks.values():
            item_copy = duplicate_track(item)
            item_copy.SetNetCode(0)
            if angle := get_orientation(switch):
                rotate(item_copy, origin, angle)
            if KICAD_VERSION < (7, 0, 0):
                item_copy.Move(pcbnew.wxPoint(-origin.x, -origin.y))
            else:
                item_copy.Move(pcbnew.VECTOR2I(-origin.x, -origin.y))

            if route:
                self.board.RemoveNative(item)
            result.append(item_copy)

        def _format_item(item: pcbnew.PCB_TRACK) -> str:
            if KICAD_VERSION >= (7, 0, 0):
                name = item.GetFriendlyName()
            else:
                name = "Via" if item.Type() == pcbnew.PCB_VIA_T else "Track"
            start = item.GetStart()
            end = item.GetEnd()
            return f"{name} [{start} {end}]"

        items_str = ", ".join([_format_item(i) for i in result])
        logger.info(f"Got connection template: {items_str}")

        if destination_path:
            pattern = re.compile(diode_format.format("(\\d)+"))
            diodes = [
                f
                for f in self.board.GetFootprints()
                if get_common_nets(f, switch) and re.match(pattern, f.GetReference())
            ]
            self.save_connection_template(switch, diodes, result, destination_path)

        return result

    def load_kicad_pcb_preset(
        self, source_path: str, key_format: str, diode_format: str
    ) -> ConnectionPreset:
        template = self.load_template(source_path)
        template_matrix = KeyMatrix(template, key_format, diode_format)
        number_of_template_switches = template_matrix.number_of_switches()
        if number_of_template_switches != 1:
            msg = (
                f"Template file '{source_path}' "
                "must have exactly one switch. "
                f"Found {number_of_template_switches} switches using "
                f"'{key_format}' annotation format."
            )
            raise PluginError(msg)
        switch_reference = template_matrix.first_switch_reference()
        switch = template_matrix.switch_by_reference(switch_reference)
        diodes = template_matrix.diodes_by_switch_reference(switch_reference)
        positions = [
            self.get_current_relative_element_position(switch, diode)
            for diode in diodes
        ]
        tracks = normalize_template_tracks(list(template.GetTracks()), switch)
        return ConnectionPreset(positions, tracks, source_board=template)

    def load_json_preset(self, source_path: str) -> ConnectionPreset:
        preset = load_switch_preset(source_path)
        return ConnectionPreset(
            preset_diode_positions(preset),
            preset_items_to_tracks(self.board, preset),
        )

    def _get_connection_preset(
        self, element_info: ElementInfo, key_format: str
    ) -> ConnectionPreset:
        path = self._normalize_template_path(element_info.template_path)
        if path not in self._connection_presets:
            logger.info(f"Loading connection preset from {path}")
            if is_json_preset(path):
                preset = self.load_json_preset(path)
            else:
                preset = self.load_kicad_pcb_preset(
                    path, key_format, element_info.annotation_format
                )
            self._connection_presets[path] = preset
        return self._connection_presets[path]

    def _calculate_reference_coordinate(
        self,
        keyboard: Keyboard,
        key_matrix: KeyMatrix,
        key_distance_x: int,
        key_distance_y: int,
        start_index: int,
    ) -> pcbnew.VECTOR2I:
        """Calculates value of offset vector to be applied to key coordinates
        in order to align first key center with defined x/y grid
        """

        def _offset(
            grid: Union[int, float],
            coordinate: Union[int, float],
            size: Union[int, float],
        ) -> int:
            if not grid:
                return 0
            pos = (grid * coordinate) + (grid * size // 2)
            quotient = pos // grid
            # add to avoid placing next to drawing sheet borders (it just looks better):
            margin = 2
            return int(grid * (quotient + margin) - pos)

        offset_x = 0
        offset_y = 0
        key_iterator: Iterator = get_key_iterator(keyboard, key_matrix, start_index)
        first_key, _ = next(key_iterator)
        if first_key:
            offset_x = _offset(key_distance_x, first_key.x, first_key.width)
            offset_y = _offset(key_distance_y, first_key.y, first_key.height)
        return pcbnew.VECTOR2I(offset_x, offset_y)

    def _resolve_key_distance(
        self,
        keyboard: Keyboard,
        key_distance: Optional[Tuple[float, float]] = None,
    ) -> Tuple[float, float]:
        """Determine key distance based on priority: argument > metadata > default.

        If key_distance was provided as argument, use it (higher priority),
        otherwise use metadata spacing

        :param keyboard: Keyboard object with metadata
        :param key_distance: Optional key distance override in millimeters
        :return: Tuple of (spacing_x, spacing_y) in millimeters
        """
        if key_distance is not None:
            return key_distance
        return (keyboard.meta.spacing_x, keyboard.meta.spacing_y)

    def place_switches(
        self,
        keyboard: Keyboard,
        key_matrix: KeyMatrix,
        key_info: ElementInfo,
        key_distance: Optional[Tuple[float, float]] = None,
        layout_offset: Optional[Tuple[float, float]] = None,
        encoder_adjustment: Optional[Tuple[float, float]] = None,
    ) -> None:
        key_position = key_info.position
        start_index = key_info.start_index

        # Determine final key_distance and update internal values
        final_key_distance = self._resolve_key_distance(keyboard, key_distance)
        logger.info(f"Using key 1U distance: {final_key_distance} mm")
        key_distance_x = cast(int, pcbnew.FromMM(final_key_distance[0]))
        key_distance_y = cast(int, pcbnew.FromMM(final_key_distance[1]))
        if layout_offset is not None:
            # Use the topmost/leftmost key (by KLE coordinates) as the reference,
            # consistent with other KLE tooling. This is independent of matrix
            # annotation order which may differ for annotated layouts.
            ref_key = min(keyboard.keys, key=lambda k: (k.y, k.x))
            ref_center_x = int(key_distance_x * (ref_key.x + ref_key.width / 2))
            ref_center_y = int(key_distance_y * (ref_key.y + ref_key.height / 2))
            offset = pcbnew.VECTOR2I(
                int(pcbnew.FromMM(layout_offset[0])) - ref_center_x,
                int(pcbnew.FromMM(layout_offset[1])) - ref_center_y,
            )
        else:
            offset = self._calculate_reference_coordinate(
                keyboard, key_matrix, key_distance_x, key_distance_y, start_index
            )
        logger.info(f"Layout offset: {offset}")
        key_iterator: Iterator = get_key_iterator(keyboard, key_matrix, start_index)

        if (
            isinstance(key_iterator, KeyboardSwitchIterator)
            and not key_iterator.explicit_annotations
        ):
            layout_tags = layout_classification(keyboard)
            if (
                KeyboardTag.COLUMN_STAGGERED in layout_tags
                or KeyboardTag.OTHER in layout_tags
            ):
                msg = (
                    "Layout of this kind with missing key matrix annotations may "
                    "produce unexpected footprint order. "
                    f"For details see: {ANNOTATION_GUIDE_URL}"
                )
                logger.warning(msg)

        self._stab_rotation_by_switch: dict = {}
        for key, switch_footprint in key_iterator:
            reset_rotation(switch_footprint)
            if key_position:
                set_side(switch_footprint, key_position.side)
                set_rotation(switch_footprint, key_position.orientation)

            position = (
                pcbnew.VECTOR2I(
                    int(key_distance_x * (key.x + key.width / 2)),
                    int(key_distance_y * (key.y + key.height / 2)),
                )
                + offset
            )
            if encoder_adjustment and key.sm == "rot_ec11":
                position = position + pcbnew.VECTOR2I_MM(
                    encoder_adjustment[0], encoder_adjustment[1]
                )
            set_position(switch_footprint, position)

            angle = key.rotation_angle
            if angle != 0:
                rotation_reference = (
                    pcbnew.VECTOR2I(
                        int(key_distance_x * key.rotation_x),
                        int(key_distance_y * key.rotation_y),
                    )
                    + offset
                )
                rotate(switch_footprint, rotation_reference, angle)

            if key.switchRotation != 0 and key.switchRotation % 90 == 0:
                switch_center = get_position(switch_footprint)
                rotate(switch_footprint, switch_center, key.switchRotation)
            elif key.switchRotation != 0:
                logger.error(
                    "Not supporting individual switch rotation other than multiple of 90 degrees. "
                    f"Got switch rotation of {key.switchRotation}, ignoring."
                )

            # Vertical keys (taller than wide, e.g. a 2U numpad key or ISO Enter)
            # need their stabilizer rotated 90 degrees so the bar runs along the
            # key's long axis. +90 in KLE convention (clockwise positive) maps
            # to KiCad orientation -90.
            auto_stab_rotation = (
                90 if (is_iso_enter(key) or key.height > key.width) else 0
            )
            self._stab_rotation_by_switch[switch_footprint.GetReference()] = (
                key.stabRotation,
                auto_stab_rotation,
            )

    def place_element(
        self,
        footprint: pcbnew.FOOTPRINT,
        element_position: ElementPosition,
        reference_position: pcbnew.VECTOR2I,
        reference_orientation: float,
    ) -> None:
        reset_rotation(footprint)
        set_side(footprint, element_position.side)
        set_rotation(footprint, element_position.orientation)

        offset = pcbnew.VECTOR2I_MM(element_position.x, element_position.y)
        if reference_orientation != 0:
            offset = position_in_rotated_coordinates(offset, reference_orientation)

        set_position(footprint, reference_position + offset)
        if reference_orientation != 0:
            current_position = get_position(footprint)
            rotate(footprint, current_position, -1 * reference_orientation)

    def place_diodes(
        self,
        diode_infos: List[ElementInfo],
        key_matrix: KeyMatrix,
    ) -> None:
        if diode_infos and diode_infos[0].position:
            # one diode can be associated with more than one switch,
            # for example for via-annotated alternative keys or when using
            # SOT-23 package or similar, keep track of placed diodes to avoid
            # placing one diode twice.
            placed_diodes: List[pcbnew.FOOTPRINT] = []
            for (
                reference,
                switch_footprint,
            ) in key_matrix.switches_by_reference_ordered():
                diodes = key_matrix.diodes_by_switch_reference(reference)
                switch_position = get_position(switch_footprint)
                switch_orientation = get_orientation(switch_footprint)
                for diode, info in zip(diodes, diode_infos):
                    if info.position and diode not in placed_diodes:
                        self.place_element(
                            diode,
                            info.position,
                            switch_position,
                            switch_orientation,
                        )
                        placed_diodes.append(diode)

    def optimize_diodes_orientation(
        self,
        key_matrix: KeyMatrix,
    ) -> None:
        for (
            reference,
            switch,
        ) in key_matrix.switches_by_reference_ordered():
            diodes = key_matrix.diodes_by_switch_reference(reference)
            logger.info(f"Optimizing orientation of {switch.GetReference()} diodes")
            for diode in diodes:
                if pads := get_closest_pads_on_same_net(diode, switch):
                    distance1 = get_distance(*pads)
                    position = get_position(diode)
                    rotate(diode, position, 180)
                    distance2 = get_distance(*pads)
                    diff = abs(distance1 - distance2)
                    # if first was shorter or approximately the same (less than 0.01mm)
                    # then go back to initial orientation
                    if distance1 < distance2 or diff < 10000:
                        rotate(diode, position, 180)
                    else:
                        logger.info(
                            f"Rotated {diode.GetReference()} to minimize distance"
                        )
                else:
                    logger.error(
                        "Could not find pads with the same net, "
                        "diode optimization skipped"
                    )

    def rotate_stabilizer(self, switch_reference: str, stabilizer: pcbnew.FOOTPRINT):
        user_rotation, auto_rotation = self._stab_rotation_by_switch.get(
            switch_reference, (0, 0)
        )
        stab_center = get_position(stabilizer)

        # Automatic rotation for vertical keys (height > width / ISO Enter).
        # Always a multiple of 90, applied unconditionally.
        if auto_rotation:
            rotate(stabilizer, stab_center, auto_rotation)

        # Per-key user override, must be a multiple of 90 degrees.
        if user_rotation != 0 and user_rotation % 90 == 0:
            rotate(stabilizer, stab_center, user_rotation)
        elif user_rotation != 0:
            logger.error(
                "Not supporting individual stabilizer rotation other than multiple of 90 degrees."
                f"Got stabilizer rotation of {user_rotation}, ignoring."
            )

    def place_switch_elements(
        self,
        elements: List[ElementInfo],
        key_matrix: KeyMatrix,
    ) -> None:
        for reference, switch_footprint in key_matrix.switches_by_reference():
            logger.info(f"Placing additional elements for {reference}")
            switch_position = get_position(switch_footprint)
            switch_orientation = get_orientation(switch_footprint)
            match = re.match(key_matrix.key_pattern, reference)
            # ommit reference prefix in order to properly match additional element
            # i.e SW1 -> LED1, SW20_1 -> ST20_1
            reference_value = match.group(1) if match else ""
            for element_info in elements:
                footprint = get_optional_footprint(
                    self.board,
                    element_info.annotation_format.format(reference_value),
                )
                if footprint and element_info.position:
                    self.place_element(
                        footprint,
                        element_info.position,
                        switch_position,
                        switch_orientation,
                    )
                    # Apply stab_rotation to stabilizer elements only.
                    # Heuristic: a reference starting with "ST" (e.g. ST{},
                    # ST20_1) or a footprint name containing "stabilizer"
                    # (case-insensitive) identifies a stabilizer footprint.
                    footprint_name = str(footprint.GetFPID().GetLibItemName())
                    is_stabilizer = (
                        footprint.GetReference().startswith("ST")
                        or "stabilizer" in footprint_name.lower()
                    )
                    if is_stabilizer:
                        self.rotate_stabilizer(reference, footprint)

    def route_switches_with_diodes(
        self,
        key_matrix: KeyMatrix,
        template_connection: List[pcbnew.PCB_TRACK],
    ) -> Dict[str, List[pcbnew.PCB_TRACK]]:
        """
        :return: Template elements placed for each switch reference
                 (empty when template is not used). These are board items,
                 they must not be accessed once removed from the board.
        """
        placed_by_switch: Dict[str, List[pcbnew.PCB_TRACK]] = {}
        if template_connection:
            total = len(template_connection)
            for reference, switch_footprint in key_matrix.switches_by_reference():
                angle = -1 * switch_footprint.GetOrientationDegrees()
                placed = self.apply_switch_connection_template(
                    switch_footprint, angle, template_connection
                )
                placed_by_switch[reference] = placed
                if rejected := total - len(placed):
                    logger.warning(
                        f"{reference}: {rejected} of {total} template elements "
                        "could not be placed due to collisions"
                    )
            if placed_by_switch and not any(placed_by_switch.values()):
                msg = (
                    "None of the switch-diode template elements could be placed, "
                    "template does not fit used footprints or their placement"
                )
                raise PluginError(msg)
            # template items are copies which are never added to the board,
            # so there is nothing to remove (note that they can't be matched with
            # board items by UUID, `Duplicate` preserves it on KiCad 6)
        else:
            for reference, switch_footprint in key_matrix.switches_by_reference():
                diodes = key_matrix.diodes_by_switch_reference(reference)
                self.route_switch_with_diode(switch_footprint, diodes)
        return placed_by_switch

    def check_switches_on_front(self, key_matrix: KeyMatrix) -> None:
        """JSON presets are defined for front side switches and are not flipped,
        replicating them to back side switches would connect wrong pads."""
        flipped = [
            reference
            for reference, switch in key_matrix.switches_by_reference()
            if switch.IsFlipped()
        ]
        if flipped:
            msg = (
                "JSON switch presets support only front side switches, "
                f"found switches on the back side: {', '.join(flipped)}"
            )
            raise PluginError(msg)

    def check_relative_diode_positions(self, key_matrix: KeyMatrix) -> None:
        """Logs warning for each switch whose diodes are placed differently
        (relative to the switch) than the diodes of the first switch.
        Used when diodes are not placed by kbplacer but routed with template
        which assumes the same relative position for each switch.
        """

        tolerance = 0.001  # mm and degrees

        def _same(p1: ElementPosition, p2: ElementPosition) -> bool:
            angle_diff = (p1.orientation - p2.orientation) % 360
            return (
                abs(p1.x - p2.x) < tolerance
                and abs(p1.y - p2.y) < tolerance
                and min(angle_diff, 360 - angle_diff) < tolerance
                and p1.side == p2.side
            )

        expected: Optional[List[ElementPosition]] = None
        expected_reference = ""
        mismatched = []
        for reference, switch in key_matrix.switches_by_reference_ordered():
            positions = [
                self.get_current_relative_element_position(switch, d)
                for d in key_matrix.diodes_by_switch_reference(reference)
            ]
            if expected is None:
                expected = positions
                expected_reference = reference
            elif len(positions) != len(expected) or not all(
                _same(p1, p2) for p1, p2 in zip(positions, expected)
            ):
                mismatched.append(reference)
        if mismatched:
            logger.warning(
                "Diodes of switches "
                f"{', '.join(mismatched)} are placed differently than diodes of "
                f"{expected_reference}, switch-diode template tracks may not "
                "connect them"
            )

    def check_template_connections(
        self,
        key_matrix: KeyMatrix,
        placed_by_switch: Dict[str, List[pcbnew.PCB_TRACK]],
    ) -> None:
        """Logs warning for each switch whose template tracks do not connect it
        with its diodes or which connect pads of different nets.

        Only template elements placed for a given switch and pads of that switch
        and its diodes are considered, tracks connect by matching endpoints.
        Must be called before any of placed elements is removed from the board.
        Removing dangling tracks later does not change the result, chain of
        tracks connecting two pads never has dangling end.
        """
        unconnected = []
        shorts = []
        for reference, tracks in placed_by_switch.items():
            switch = key_matrix.switch_by_reference(reference)
            diodes = key_matrix.diodes_by_switch_reference(reference)
            groups = _group_connected_pads(switch, diodes, tracks)
            for diode in diodes:
                diode_reference = diode.GetReference()
                nets = {n for n in get_common_nets(switch, diode) if n != 0}
                if nets and not any(
                    _group_connects(g, reference, diode_reference, nets) for g in groups
                ):
                    unconnected.append(f"{reference}-{diode_reference}")

            for group in groups:
                netnames = sorted({p.GetNetname() for _, p in group if p.GetNetCode()})
                if len(netnames) > 1:
                    shorts.append(f"{reference} ({', '.join(netnames)})")

        if unconnected:
            logger.warning(
                "Switch-diode template did not connect: "
                f"{', '.join(unconnected)}. Check that template matches used "
                "footprints and diode position."
            )
        if shorts:
            logger.warning(
                "Switch-diode template connects pads of different nets: "
                f"{', '.join(shorts)}. Check that template matches used "
                "footprints and diode position."
            )

    def route_rows_and_columns(self, key_matrix: KeyMatrix) -> None:
        pads = get_pads_by_net(self.board)

        matrix_net_names = key_matrix.matrix_nets()
        matrix_pads = {net: pads[net] for net in matrix_net_names}
        for net, pads in matrix_pads.items():
            logger.info(f"Routing {net} pads")
            distances = calculate_distance_matrix(cast(List[pcbnew.BOARD_ITEM], pads))
            result = prim_mst(distances)
            for i, j in result:
                p1 = pads[i]
                p2 = pads[j]
                if p1.GetParentAsString() != p2.GetParentAsString():
                    self.route(p1, p2)

    def load_template(self, template_path: str) -> pcbnew.BOARD:
        if KICAD_VERSION >= (8, 0, 0):
            return pcbnew.PCB_IO_MGR.Load(pcbnew.PCB_IO_MGR.KICAD_SEXP, template_path)  # type: ignore
        return pcbnew.IO_MGR.Load(pcbnew.IO_MGR.KICAD_SEXP, template_path)  # type: ignore

    def _normalize_template_path(self, template_path: str) -> str:
        if not template_path:
            msg = "Template path can't be empty"
            raise PluginError(msg)
        if str(Path(template_path).name) == template_path:
            # if passed filename without directory,
            # assume that this refers to file in the directory of
            # current board. This is mostly for CLI convenience
            template_path = str(Path(self.board.GetFileName()).parent / template_path)
        return template_path

    def _get_relative_position_source(self, element: ElementInfo) -> pcbnew.BOARD:
        if element.position_option == PositionOption.PRESET:
            path = self._normalize_template_path(element.template_path)
            if is_json_preset(path):
                msg = (
                    f"JSON preset '{element.template_path}' can't be used for "
                    f"'{element.annotation_format}' elements, JSON presets "
                    "are supported only for diodes"
                )
                raise PluginError(msg)
            return self.load_template(path)
        else:
            return self.board

    def _update_element_position(
        self, key_info: ElementInfo, element: ElementInfo
    ) -> None:
        if element.position_option in [
            PositionOption.RELATIVE,
            PositionOption.PRESET,
        ]:
            source = self._get_relative_position_source(element)
            # Extract start_index from key_info
            element1 = get_footprint(
                source, key_info.annotation_format.format(key_info.start_index)
            )
            element2 = get_footprint(
                source, element.annotation_format.format(key_info.start_index)
            )
            element.position = self.get_current_relative_element_position(
                element1, element2
            )
            logger.info(f"Element info updated: {element}")

    def _prepare_diode_infos(
        self, key_matrix: KeyMatrix, diode_info: ElementInfo
    ) -> List[ElementInfo]:
        infos = []
        if diode_info.position_option == PositionOption.PRESET:
            preset = self._get_connection_preset(diode_info, key_matrix.key_format)
            if preset.diode_positions is None:
                logger.info("Preset does not define diode positions, not moving diodes")
                temp_info = copy.copy(diode_info)
                temp_info.position = None
                infos.append(temp_info)
            for position in preset.diode_positions or []:
                temp_info = copy.copy(diode_info)
                temp_info.position = position
                logger.info(f"Element info updated: {temp_info}")
                infos.append(temp_info)
        elif diode_info.position_option == PositionOption.RELATIVE:
            template_matrix = KeyMatrix(
                self.board, key_matrix.key_format, diode_info.annotation_format
            )
            first_switch = template_matrix.first_switch_reference()
            switch = template_matrix.switch_by_reference(first_switch)
            diodes = template_matrix.diodes_by_switch_reference(switch.GetReference())
            for diode in diodes:
                temp_info = copy.copy(diode_info)
                temp_info.position = self.get_current_relative_element_position(
                    switch, diode
                )
                logger.info(f"Element info updated: {temp_info}")
                infos.append(temp_info)
        else:
            infos.append(diode_info)
        return infos

    def _get_template_connection(
        self, key_info: ElementInfo, diode_info: ElementInfo, route: bool
    ) -> List[pcbnew.PCB_TRACK]:
        if diode_info.position_option in [
            PositionOption.RELATIVE,
            PositionOption.UNCHANGED,
        ]:
            return self.get_connection_template(
                key_info,  # Pass full ElementInfo instead of individual fields
                diode_info.annotation_format,
                diode_info.template_path,
                route,
            )
        elif diode_info.position_option == PositionOption.PRESET:
            preset = self._get_connection_preset(diode_info, key_info.annotation_format)
            if route and not preset.tracks:
                msg = (
                    f"Preset '{diode_info.template_path}' has no tracks, "
                    "switch-diode routing with preset is not possible"
                )
                raise PluginError(msg)
            return preset.tracks
        else:
            return []

    def run(
        self,
        layout_path: str,
        key_info: ElementInfo,
        diode_info: ElementInfo,
        route_switches_with_diodes: bool = False,
        route_rows_and_columns: bool = False,
        additional_elements: List[ElementInfo] = [],
        optimize_diodes_orientation: bool = False,
        key_distance: Optional[Tuple[float, float]] = None,
        layout_offset: Optional[Tuple[float, float]] = None,
        encoder_adjustment: Optional[Tuple[float, float]] = None,
    ) -> None:
        if key_info.start_index < 0:
            logger.warning(
                f"Invalid switch start index: {key_info.start_index}, defaults to 1"
            )
            key_info.start_index = 1
        # stage 1 - prepare
        key_matrix = KeyMatrix(
            self.board, key_info.annotation_format, diode_info.annotation_format
        )
        if (
            key_matrix.any_switch_with_multiple_diodes()
            and diode_info.position_option
            in [
                PositionOption.DEFAULT,
                PositionOption.CUSTOM,
            ]
        ):
            msg = (
                f"The '{diode_info.position_option}' position not supported for "
                f"multiple diodes per switch layouts, use '{PositionOption.RELATIVE}' "
                f"or '{PositionOption.PRESET}' position option.\n"
                f"When using '{diode_info.position_option}' ensure that each switch "
                "has exactly one diode connected to it."
            )
            raise PluginError(msg)

        if (
            diode_info.position_option == PositionOption.PRESET
            and route_switches_with_diodes
            and optimize_diodes_orientation
        ):
            msg = (
                f"The '{PositionOption.PRESET}' position option with switch-diode "
                "routing can't be used with diodes orientation optimization, "
                "preset tracks assume the same diode orientation for each switch"
            )
            raise PluginError(msg)

        number_of_switches = key_matrix.number_of_switches()
        if number_of_switches == 0:
            msg = (
                f"No switch footprints found using '{key_info.annotation_format}' "
                "annotation format. Make sure that switches are added to opened "
                "PCB file and theirs annotations match configured value."
            )
            raise PluginError(msg)

        # it is important to get template connection
        # and relative positions before moving any elements
        template_connection = self._get_template_connection(
            key_info, diode_info, route_switches_with_diodes
        )

        diode_infos = self._prepare_diode_infos(key_matrix, diode_info)
        for element_info in additional_elements:
            self._update_element_position(key_info, element_info)

        # stage 2 - place elements
        if layout_path:
            keyboard = get_keyboard_from_path_or_url(layout_path)

            if not isinstance(keyboard, MatrixAnnotatedKeyboard):
                # if not MatrixAnnotatedKeyboard already,
                # check if it is possible to convert
                try:
                    keyboard = MatrixAnnotatedKeyboard(keyboard.meta, keyboard.keys)
                    logger.info(
                        "Detected layout convertible to matrix annotated keyboard"
                    )
                except Exception:
                    pass
            if isinstance(keyboard, MatrixAnnotatedKeyboard):
                # can be called only once:
                keyboard.collapse()
            self.place_switches(
                keyboard,
                key_matrix,
                key_info,
                key_distance,
                layout_offset,
                encoder_adjustment=encoder_adjustment,
            )

        logger.info(f"Diode info: {diode_infos}")
        if diode_info.position_option != PositionOption.UNCHANGED:
            self.place_diodes(diode_infos, key_matrix)
            if optimize_diodes_orientation:
                self.optimize_diodes_orientation(key_matrix)

        if additional_elements:
            self.place_switch_elements(additional_elements, key_matrix)

        # stage 3 - route elements
        if route_switches_with_diodes:
            if (
                template_connection
                and diode_info.position_option == PositionOption.PRESET
                and is_json_preset(diode_info.template_path)
            ):
                self.check_switches_on_front(key_matrix)
            if template_connection and not any(i.position for i in diode_infos):
                self.check_relative_diode_positions(key_matrix)
            placed_by_switch = self.route_switches_with_diodes(
                key_matrix, template_connection
            )
            # check before removing dangling tracks, which invalidates removed items
            if placed_by_switch:
                self.check_template_connections(key_matrix, placed_by_switch)
            del placed_by_switch

        if route_rows_and_columns:
            self.route_rows_and_columns(key_matrix)

        if route_switches_with_diodes or route_rows_and_columns:
            self.remove_dangling_tracks()
