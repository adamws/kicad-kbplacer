# SPDX-FileCopyrightText: 2025 adamws <adamws@users.noreply.github.com>
#
# SPDX-License-Identifier: GPL-3.0-or-later

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Tuple

import pcbnew

from .board_builder import BoardBuilder
from .edge_generator import build_board_outline
from .element_position import ElementInfo, PositionOption
from .kbplacer_dialog import WindowState
from .key_placer import KeyPlacer
from .schematic_builder import can_create_schematic, create_schematic
from .template_copier import copy_from_template_to_board


@dataclass
class PluginSettings:
    pcb_file_path: str
    layout_path: str
    key_info: ElementInfo
    key_distance: Optional[Tuple[float, float]]
    diode_info: ElementInfo
    route_switches_with_diodes: bool
    optimize_diodes_orientation: bool
    route_rows_and_columns: bool
    additional_elements: List[ElementInfo]
    generate_outline: bool
    outline_delta: float
    template_path: str
    create_pcb_file: bool
    create_sch_file: bool
    sch_file_path: str
    switch_footprint: str
    diode_footprint: str
    stabilizer_footprint: str
    encoder_footprint: str = ""
    layout_offset: Optional[Tuple[float, float]] = None
    add_stabilizers: bool = True
    encoder_adjustment: Optional[Tuple[float, float]] = None


def run_schematic(settings: PluginSettings):
    if settings.create_sch_file:
        if not can_create_schematic():
            msg = "Requires optional schematic dependencies"
            raise RuntimeError(msg)
        create_schematic(
            settings.layout_path,
            settings.sch_file_path,
            switch_footprint=settings.switch_footprint,
            diode_footprint=settings.diode_footprint,
            stabilizer_footprint=settings.stabilizer_footprint,
            encoder_footprint=settings.encoder_footprint,
            add_stabilizers=settings.add_stabilizers,
        )


def run_board(settings: PluginSettings) -> pcbnew.BOARD:
    if settings.create_pcb_file:
        builder = BoardBuilder(
            settings.pcb_file_path,
            switch_footprint=settings.switch_footprint,
            diode_footprint=settings.diode_footprint,
            stabilizer_footprint=settings.stabilizer_footprint,
            encoder_footprint=settings.encoder_footprint,
        )
        board = builder.create_board(
            settings.layout_path, add_stabilizers=settings.add_stabilizers
        )
    else:
        board = pcbnew.LoadBoard(settings.pcb_file_path)

    placer = KeyPlacer(board)
    placer.run(
        settings.layout_path,
        settings.key_info,
        settings.diode_info,
        settings.route_switches_with_diodes,
        settings.route_rows_and_columns,
        additional_elements=settings.additional_elements,
        optimize_diodes_orientation=settings.optimize_diodes_orientation,
        key_distance=settings.key_distance,
        layout_offset=settings.layout_offset,
        encoder_adjustment=settings.encoder_adjustment,
    )

    if settings.generate_outline:
        build_board_outline(
            board, settings.outline_delta, settings.key_info.annotation_format
        )

    if settings.template_path:
        copy_from_template_to_board(
            board, settings.template_path, settings.route_rows_and_columns
        )

    return board


def run_from_gui(pcb_file_path: str, state: WindowState) -> pcbnew.BOARD:
    """Same as 'run' but with additional WindowState to PluginSettings translation"""
    if not state.enable_diode_placement:
        state.diode_info.position_option = PositionOption.UNCHANGED
        state.diode_info.template_path = ""

    settings = PluginSettings(
        pcb_file_path=pcb_file_path,
        layout_path=state.layout_path,
        key_info=state.key_info,
        key_distance=state.key_distance,
        layout_offset=state.layout_offset,
        diode_info=state.diode_info,
        route_switches_with_diodes=state.route_switches_with_diodes,
        optimize_diodes_orientation=state.optimize_diodes_orientation,
        route_rows_and_columns=state.route_rows_and_columns,
        additional_elements=state.additional_elements,
        generate_outline=state.generate_outline,
        outline_delta=state.outline_delta,
        template_path=state.template_path,
        create_pcb_file=False,
        create_sch_file=False,
        sch_file_path="",
        switch_footprint="",
        diode_footprint="",
        stabilizer_footprint="",
    )
    return run_board(settings)
